import httpx
from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles

app = FastAPI()
API = "https://en.wikisource.org/w/api.php"
HEADERS = {"User-Agent": "PanAfricanLegalArchives/1.0 (mustaphasunkanmi@gmail.com)"}

app.mount("/static", StaticFiles(directory="static"), name="static")


@app.get("/")
async def index():
    return FileResponse("templates/index.html")


@app.get("/cases")
async def list_cases():
    params = {
        "action": "query",
        "generator": "links",
        "titles": "Portal: Ghana High Court",
        "gplnamespace": 0,
        "gpllimit": "max",
        "prop": "info",
        "format": "json",
        "formatversion": 2,
    }

    cases = []
    async with httpx.AsyncClient(headers=HEADERS) as client:
        while True:
            response = await client.get(API, params=params)
            response.raise_for_status()
            data = response.json()

            pages = data["query"].get("pages", [])
            cases.extend(page["title"] for page in pages if not page.get("missing"))

            if "continue" not in data:
                break
            params.update(data["continue"])

    return sorted(cases)


@app.get("/case")
async def get_case(title: str):
    if not title:
        raise HTTPException(400, "title is required")

    params = {
        "action": "parse",
        "page": title,
        "prop": "text",
        "format": "json",
        "formatversion": 2,
    }

    async with httpx.AsyncClient(headers=HEADERS) as client:
        response = await client.get(API, params=params)
        response.raise_for_status()
        data = response.json()

    if "error" in data or "parse" not in data:
        raise HTTPException(404, "case not found")

    parsed_text = data["parse"].get("text")
    html = parsed_text.get("*") if isinstance(parsed_text, dict) else parsed_text
    if not html:
        raise HTTPException(404, "case content not found")

    return {"title": title, "html": html}